from django.contrib import admin
from django.urls import path, include
from dashboard import views
from django.contrib.auth import views as auth_views
from rest_framework import routers
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

router = routers.DefaultRouter()
router.register(r'users', views.UserViewSet)
router.register(r'offices', views.OfficeViewSet)
router.register(r'meeting-requests', views.MeetingRequestViewSet)
router.register(r'branding-requests', views.BrandingRequestViewSet)
router.register(r'chats', views.ChatManagementViewSet, basename='chat')

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.dashboard, name='dashboard'),
    path('users-management/', views.users_management, name='users_management'),
    path('offices-management/', views.offices_management, name='offices_management'),
    path('chat-management/', views.chat_management, name='chat_management'),
    path('meeting-requests/', views.meeting_requests, name='meeting_requests'),
    path('branding-requests/', views.branding_requests, name='branding_requests'),
    path('analytics-reports/', views.analytics_reports, name='analytics_reports'),
    path('user/<int:user_id>/', views.user_detail, name='user_detail'),  # This view is missing in your views.py
    path('users/edit/<int:user_id>/', views.edit_user, name='edit_user'),
    path('users/delete/<int:user_id>/', views.delete_user, name='delete_user'),   # This view is missing in your views.py
    path('users/add/', views.add_user, name='add_user'),  # This view is missing in your views.py
    path('office/<int:office_id>/edit/', views.office_edit, name='office_edit'),  # This view is missing in your views.py
    path('meeting-request/<int:request_id>/approve/', views.approve_meeting_request, name='approve_meeting_request'),  # This view is missing in your views.py
    path('meeting-request/<int:request_id>/deny/', views.deny_meeting_request, name='deny_meeting_request'),  # This view is missing in your views.py
    path('branding-request/<int:request_id>/approve/', views.approve_branding_request, name='approve_branding_request'),  # This view is handled by the BrandingRequestViewSet
    path('branding-request/<int:request_id>/deny/', views.deny_branding_request, name='deny_branding_request'),  # This view is handled by the BrandingRequestViewSet
    path('branding-request/<int:request_id>/request-changes/', views.request_changes_branding_request, name='request_changes_branding_request'),  # This view is handled by the BrandingRequestViewSet

    # Include Django's built-in authentication URLs
    path('accounts/', include('django.contrib.auth.urls')),
    path('login/', auth_views.LoginView.as_view(template_name='dashboard/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),

    path('', include(router.urls)),
    path('api-auth/', include('rest_framework.urls', namespace='rest_framework')),
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
]
