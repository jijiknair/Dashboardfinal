from django import forms
from .models import Office, BrandingRequest
from django.contrib.auth.models import User
from .models import Profile
from django.contrib.auth.forms import UserCreationForm

class UserForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']

    def clean_username(self):
        username = self.cleaned_data.get('username')
        if User.objects.filter(username=username).exists():
            raise forms.ValidationError("A user with that username already exists.")
        return username

class ProfileForm(forms.ModelForm):
    status = forms.CharField(required=False)  # Set the status field as not required

class ProfileForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ['status', 'office_rented', 'office_name']

    def __init__(self, *args, **kwargs):
        super(ProfileForm, self).__init__(*args, **kwargs)
        for field in self.fields:
            self.fields[field].required = False
        
class UserEditForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['username', 'email']  # Only include fields that should be editable

    def __init__(self, *args, **kwargs):
        super(UserEditForm, self).__init__(*args, **kwargs)
        # Make fields not required
        for field in self.fields:
            self.fields[field].required = False

            
class OfficeForm(forms.ModelForm):
    class Meta:
        model = Office
        fields = ['name', 'owner', 'status', 'rental_price']

    def __init__(self, *args, **kwargs):
        super(OfficeForm, self).__init__(*args, **kwargs)
        for field in self.fields:
            self.fields[field].required = False


# Add the BrandingChangeRequestForm to handle branding change requests
class BrandingChangeRequestForm(forms.ModelForm):
    class Meta:
        model = BrandingRequest
        fields = ['change_description']  # This assumes you have a field named 'change_description'