from django.contrib import admin
from .models import Profile, Office, MeetingRequest, BrandingRequest, RecentActivity, Chat

# Register each model with the admin site
admin.site.register(Profile)
admin.site.register(Office)
admin.site.register(MeetingRequest)
admin.site.register(BrandingRequest)
admin.site.register(RecentActivity)
admin.site.register(Chat)
