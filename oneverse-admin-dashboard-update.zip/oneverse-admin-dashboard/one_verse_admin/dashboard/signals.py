from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver
from .models import Office, MeetingRequest, BrandingRequest, RecentActivity

@receiver(post_save, sender=Office)
def log_office_activity(sender, instance, created, **kwargs):
    if created:
        activity = f"Office '{instance.name}' was created."
    else:
        activity = f"Office '{instance.name}' was updated."
    RecentActivity.objects.create(description=activity)

@receiver(post_delete, sender=Office)
def log_office_deletion(sender, instance, **kwargs):
    activity = f"Office '{instance.name}' was deleted."
    RecentActivity.objects.create(description=activity)

@receiver(post_save, sender=MeetingRequest)
def log_meeting_request_activity(sender, instance, created, **kwargs):
    if created:
        activity = f"Meeting request for '{instance.office_name}' was created."
    else:
        activity = f"Meeting request for '{instance.office_name}' was updated."
    RecentActivity.objects.create(description=activity)

@receiver(post_delete, sender=MeetingRequest)
def log_meeting_request_deletion(sender, instance, **kwargs):
    activity = f"Meeting request for '{instance.office_name}' was deleted."
    RecentActivity.objects.create(description=activity)

@receiver(post_save, sender=BrandingRequest)
def log_branding_request_activity(sender, instance, created, **kwargs):
    if created:
        activity = f"Branding request for '{instance.office_name}' was created."
    else:
        activity = f"Branding request for '{instance.office_name}' was updated."
    RecentActivity.objects.create(description=activity)

@receiver(post_delete, sender=BrandingRequest)
def log_branding_request_deletion(sender, instance, **kwargs):
    activity = f"Branding request for '{instance.office_name}' was deleted."
    RecentActivity.objects.create(description=activity)
