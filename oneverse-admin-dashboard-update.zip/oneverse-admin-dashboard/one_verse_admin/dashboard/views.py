from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Profile, Office, MeetingRequest, BrandingRequest, RecentActivity, Chat
from .serializers import UserSerializer, OfficeSerializer, MeetingRequestSerializer, BrandingRequestSerializer, ChatSerializer
from .forms import UserForm, OfficeForm, ProfileForm, UserEditForm # Ensure these forms are defined in your forms.py
from django.http import JsonResponse
import logging
from rest_framework import status
from django.views.decorators.csrf import csrf_exempt


logger = logging.getLogger(__name__)


@login_required
def dashboard(request):
    total_users = User.objects.count()
    active_users = User.objects.filter(profile__status='active').count() 
    rented_offices = Office.objects.filter(status='rented').count()
    free_offices = Office.objects.filter(status='free').count()
    recent_activities = RecentActivity.objects.order_by('-activity_time')[:10]

    context = {
        'total_users': total_users,
        'active_users': active_users,
        'rented_offices': rented_offices,
        'free_offices': free_offices,
        'recent_activities': recent_activities,
    }

    return render(request, 'dashboard/dashboard.html', context)

@login_required
def users_management(request):
    users = User.objects.all()
    profiles = Profile.objects.select_related('user')

    # Zip users and profiles together
    users_profiles = zip(users, profiles)
    
    context = {
        'users_profiles': users_profiles,
        'total_users' : User.objects.count(),
        'active_users' : User.objects.filter(profile__status='active').count(),
    }
    return render(request, 'dashboard/users_management.html', context)

@login_required
@csrf_exempt  # If using AJAX, ensure CSRF tokens are handled properly
def add_user(request):
    if request.method == 'POST':
        user_form = UserForm(request.POST)
        profile_form = ProfileForm(request.POST)

        if user_form.is_valid() and profile_form.is_valid():
            user = user_form.save()

            # No need to create profile manually if the signal handles it

            return JsonResponse({'success': True, 'message': 'User added successfully!'}, status=201)
        else:
            errors = {**user_form.errors, **profile_form.errors}
            return JsonResponse({'success': False, 'errors': errors}, status=400)

    return JsonResponse({'success': False, 'message': 'Invalid request method.'}, status=405)

@login_required
def edit_user(request, user_id):
    user = get_object_or_404(User, pk=user_id)
    profile = get_object_or_404(Profile, user=user)
    
    if request.method == 'POST':
        user_form = UserEditForm(request.POST, instance=user)
        profile_form = ProfileForm(request.POST, instance=profile)
        
        if user_form.is_valid() and profile_form.is_valid():
            # Save the user form (this updates the username and email)
            user_form.save()
            
            # Check if the status field is being updated correctly
            if 'status' in profile_form.cleaned_data:
                print(f"Updating status to: {profile_form.cleaned_data['status']}")  # Debugging line
            
            # Save the profile form (this should update the status)
            profile_form.save()

            return JsonResponse({'success': True, 'message': 'User updated successfully!'}, status=200)
        else:
            errors = {**user_form.errors, **profile_form.errors}
            return JsonResponse({'success': False, 'errors': errors}, status=400)
    else:
        return JsonResponse({'success': False, 'message': 'Invalid request method'}, status=405)


    
@login_required
def user_detail(request, user_id):
    user = get_object_or_404(User, id=user_id)
    return render(request, 'dashboard/user_detail.html', {'user': user})



@login_required
def delete_user(request, user_id):
    user = get_object_or_404(User, id=user_id)
    if request.method == 'POST':
        try:
            user.delete()
            return JsonResponse({'success': True, 'message': 'User deleted successfully!'})
        except Exception as e:
            return JsonResponse({'success': False, 'message': str(e)})
    return JsonResponse({'success': False, 'message': 'Invalid request method'})


@login_required
def offices_management(request):
    offices = Office.objects.all()
    context = {
        'offices': offices,
        'total_offices': offices.count(),
        'rented_offices': offices.filter(status='rented').count(),
        'free_offices': offices.filter(status='free').count(),
    }
    return render(request, 'dashboard/offices_management.html', context)

@login_required
def office_edit(request, office_id=None):
    if office_id:
        # Get the office by ID or return 404 if it doesn't exist
        office = get_object_or_404(Office, id=office_id)
    else:
        office = None  # If no office_id is provided, we assume it's a new office creation

    if request.method == 'POST':
        form = OfficeForm(request.POST, instance=office)
        if form.is_valid():
            office = form.save(commit=False)  # Save form data without committing yet

            # Ensure the owner is correctly linked
            owner = form.cleaned_data.get('owner')
            if owner:
                office.owner = owner

                # Ensure the owner has a profile, if not, create one (though signals should handle this)
                if not hasattr(owner, 'profile'):
                    Profile.objects.create(user=owner)

            office.save()  # Save the office to the database
            return JsonResponse({'success': True, 'message': 'Office updated successfully!'})

        else:
            # If form is invalid, return errors as JSON
            return JsonResponse({'success': False, 'errors': form.errors}, status=400)

    else:
        # For GET requests, return office data as JSON for editing
        if office:
            office_data = {
                'name': office.name,
                'owner': office.owner.id if office.owner else None,
                'status': office.status,
                'rental_price': office.rental_price,
            }
            return JsonResponse({'success': True, 'office': office_data})
        else:
            return JsonResponse({'success': False, 'message': 'Office not found'}, status=404)

class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated]

    def create(self, request, *args, **kwargs):
        username = request.data.get('username')
        email = request.data.get('email')
        password = request.data.get('password')
        user = User.objects.create_user(username=username, email=email, password=password)
        profile = Profile.objects.create(
            user=user,
            office_rented=request.data.get('office_rented'),
            office_name=request.data.get('office_name'),
            status=request.data.get('status', 'active')
        )
        user.save()
        serializer = self.get_serializer(user)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def update(self, request, *args, **kwargs):
        user = self.get_object()
        profile = user.profile
        user.username = request.data.get('username', user.username)
        user.email = request.data.get('email', user.email)
        profile.office_rented = request.data.get('office_rented', profile.office_rented)
        profile.office_name = request.data.get('office_name', profile.office_name)
        profile.status = request.data.get('status', profile.status)
        user.save()
        profile.save()
        serializer = self.get_serializer(user)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def destroy(self, request, *args, **kwargs):
        user = self.get_object()
        user.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

class OfficeViewSet(viewsets.ModelViewSet):
    queryset = Office.objects.all()
    serializer_class = OfficeSerializer
    permission_classes = [IsAuthenticated]

    def create(self, request, *args, **kwargs):
        name = request.data.get('name')
        owner_id = request.data.get('owner')
        status = request.data.get('status')
        rental_price = request.data.get('rental_price')
        owner = User.objects.get(id=owner_id) if owner_id else None
        office = Office.objects.create(name=name, owner=owner, status=status, rental_price=rental_price)
        serializer = self.get_serializer(office)
        return Response(serializer.data)

    def update(self, request, *args, **kwargs):
        office = self.get_object()
        office.name = request.data.get('name', office.name)
        owner_id = request.data.get('owner')
        office.owner = User.objects.get(id=owner_id) if owner_id else office.owner
        office.status = request.data.get('status', office.status)
        office.rental_price = request.data.get('rental_price', office.rental_price)
        office.save()
        serializer = self.get_serializer(office)
        return Response(serializer.data)

    def destroy(self, request, *args, **kwargs):
        office = self.get_object()
        office.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

@login_required
def meeting_requests(request):
    requests = MeetingRequest.objects.all()
    context = {
        'requests': requests,
    }
    return render(request, 'dashboard/meeting_requests.html', context)

class MeetingRequestViewSet(viewsets.ModelViewSet):
    queryset = MeetingRequest.objects.all()
    serializer_class = MeetingRequestSerializer
    permission_classes = [IsAuthenticated]

    @action(detail=True, methods=['post'])
    def approve(self, request, pk=None):
        meeting_request = self.get_object()
        meeting_request.status = 'approved'
        meeting_request.save()
        return Response({'status': 'meeting request approved'})

    @action(detail=True, methods=['post'])
    def deny(self, request, pk=None):
        meeting_request = self.get_object()
        meeting_request.status = 'denied'
        meeting_request.save()
        return Response({'status': 'meeting request denied'})


@login_required
def approve_meeting_request(request, request_id):
    meeting_request = get_object_or_404(MeetingRequest, id=request_id)
    meeting_request.status = 'approved'
    meeting_request.save()
    messages.success(request, 'Meeting request approved!')
    return redirect('meeting_requests')

@login_required
def deny_meeting_request(request, request_id):
    meeting_request = get_object_or_404(MeetingRequest, id=request_id)
    meeting_request.status = 'denied'
    meeting_request.save()
    messages.success(request, 'Meeting request denied!')
    return redirect('meeting_requests')


@login_required
def branding_requests(request):
    requests = BrandingRequest.objects.all()
    context = {
        'requests': requests,
    }
    return render(request, 'dashboard/branding_requests.html', context)

class BrandingRequestViewSet(viewsets.ModelViewSet):
    queryset = BrandingRequest.objects.all()
    serializer_class = BrandingRequestSerializer
    permission_classes = [IsAuthenticated]

    @action(detail=True, methods=['post'])
    def approve(self, request, pk=None):
        branding_request = self.get_object()
        branding_request.status = 'approved'
        branding_request.save()
        return Response({'success': True, 'status': 'branding request approved'}, status=status.HTTP_200_OK)

    @action(detail=True, methods=['post'])
    def deny(self, request, pk=None):
        branding_request = self.get_object()
        branding_request.status = 'denied'
        branding_request.save()
        return Response({'success': True, 'status': 'branding request denied'}, status=status.HTTP_200_OK)

    @action(detail=True, methods=['post'])
    def request_changes(self, request, pk=None):
       branding_request = self.get_object()
       branding_request.status = 'pending'
       branding_request.save()
       return Response({'success': True, 'status': 'branding request changes requested'}, status=status.HTTP_200_OK)

@login_required
def approve_branding_request(request, request_id):
    branding_request = get_object_or_404(BrandingRequest, id=request_id)
    branding_request.status = 'approved'
    branding_request.save()
    messages.success(request, 'Branding request approved!')
    return redirect('branding_requests')

@login_required
def deny_branding_request(request, request_id):
    branding_request = get_object_or_404(BrandingRequest, id=request_id)
    branding_request.status = 'denied'
    branding_request.save()
    messages.success(request, 'Branding request denied!')
    return redirect('branding_requests')

@login_required
def request_changes_branding_request(request, request_id):
    branding_request = get_object_or_404(BrandingRequest, id=request_id)
    if request.method == 'POST':
        try:
            branding_request.status = 'pending'
            branding_request.save()
            return JsonResponse({'success': True, 'message': 'Change request submitted!'})
        except Exception as e:
            return JsonResponse({'success': False, 'message': str(e)})
    return JsonResponse({'success': False, 'message': 'Invalid request method'})



class ChatManagementViewSet(viewsets.ModelViewSet):
    queryset = Chat.objects.all()
    serializer_class = ChatSerializer
    permission_classes = [IsAuthenticated]

@login_required
def chat_management(request):
    context = {
        'total_text_chats': 0,  # Replace with real data
        'total_voice_chats': 0,  # Replace with real data
    }
    return render(request, 'dashboard/chat_management.html', context)

@login_required
def analytics_reports(request):
    context = {
        'charts_data': {},  # Add data for charts here
    }
    return render(request, 'dashboard/analytics_reports.html', context)
