from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from dashboard.models import Profile, Office, MeetingRequest, BrandingRequest
from faker import Faker
import random

class Command(BaseCommand):
    help = 'Create dummy data for testing'

    def handle(self, *args, **kwargs):
        faker = Faker()

        # Create Users and associated Profiles
        for _ in range(50):
            user = User.objects.create_user(
                username=faker.user_name(),
                email=faker.email(),
                password=faker.password()
            )
            
            # Create associated Profile
            Profile.objects.create(
                user=user,
                status=random.choice(['active', 'inactive']),
                office_rented=random.choice([True, False]),
                office_name=faker.company() if random.choice([True, False]) else None
            )

        # Create Offices
        for _ in range(40):
            office = Office.objects.create(
                name=faker.company(),
                owner=random.choice(User.objects.all()) if random.choice([True, False]) else None,
                status=random.choice(['rented', 'free']),
                rental_price=random.uniform(100, 1000)
            )

        # Create Meeting Requests
        for _ in range(30):
            meeting_request = MeetingRequest.objects.create(
                requester=random.choice(User.objects.all()),
                requested_time=faker.date_time_this_year(),
                requested_type=random.choice(['Conference', 'Client Meeting']),
                office_name=random.choice(Office.objects.all()).name,
                status=random.choices(
                    ['pending', 'approved', 'denied'],
                    weights=[70, 15, 15],
                    k=1
                )[0]  
            )

        # Create Branding Requests
        for _ in range(30):
            branding_request = BrandingRequest.objects.create(
                requester=random.choice(User.objects.all()),
                requested_time=faker.date_time_this_year(),
                requested_logo=faker.file_path(extension='png'),
                office_name=random.choice(Office.objects.all()).name,
                status=random.choices(
                    ['pending', 'approved', 'denied'],
                    weights=[70, 15, 15],
                    k=1
                )[0]  
            )

        self.stdout.write(self.style.SUCCESS('Dummy data created successfully'))
