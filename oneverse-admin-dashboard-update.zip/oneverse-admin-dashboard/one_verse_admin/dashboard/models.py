from django.db import models
from django.contrib.auth.models import User


class Profile(models.Model):
    USER_STATUS_CHOICES = [
        ('active', 'Active'),
        ('inactive', 'Inactive'),
    ]
    
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    status = models.CharField(max_length=10, choices=USER_STATUS_CHOICES, default='active')
    office_rented = models.BooleanField(default=False)
    office_name = models.CharField(max_length=100, null=True, blank=True)

    def __str__(self):
        return self.user.username
    

class Office(models.Model):
    OFFICE_STATUS_CHOICES = [
        ('rented', 'Rented'),
        ('free', 'Free'),
    ]
    
    name = models.CharField(max_length=100)
    owner = models.ForeignKey(User, related_name='offices', on_delete=models.SET_NULL, null=True, blank=True)
    status = models.CharField(max_length=10, choices=OFFICE_STATUS_CHOICES, default='free')
    rental_price = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return self.name


class MeetingRequest(models.Model):
    REQUEST_STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('denied', 'Denied'),
    ]
    requester = models.ForeignKey(User, on_delete=models.CASCADE)
    requested_time = models.DateTimeField()
    requested_type = models.CharField(max_length=50)
    office_name = models.CharField(max_length=100)
    status = models.CharField(max_length=10, choices=REQUEST_STATUS_CHOICES, default='pending')

    def __str__(self):
        return f'{self.requester.username} - {self.office_name}'

class BrandingRequest(models.Model):
    REQUEST_STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('denied', 'Denied'),
    ]

    requester = models.ForeignKey(User, on_delete=models.CASCADE)
    requested_time = models.DateTimeField()
    requested_logo = models.ImageField(upload_to='branding_logos/')
    office_name = models.CharField(max_length=100)
    status = models.CharField(max_length=10, choices=REQUEST_STATUS_CHOICES, default='pending')
    change_description = models.TextField(null=True, blank=True)

    def __str__(self):
        return f"Branding Request by {self.requester.username} for {self.office_name}"


class RecentActivity(models.Model):
    activity_time = models.DateTimeField(auto_now_add=True)
    description = models.TextField()

    def __str__(self):
        return self.description
    

class Chat(models.Model):
    message = models.TextField()
    sender = models.ForeignKey(User, on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.sender.username}: {self.message[:50]}'


from django.db.models.signals import post_save
from django.dispatch import receiver
from django.contrib.auth.models import User

@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(user=instance)

@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    instance.profile.save()
