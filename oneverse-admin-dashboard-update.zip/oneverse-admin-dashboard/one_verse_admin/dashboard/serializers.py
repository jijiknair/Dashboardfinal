from rest_framework import serializers
from django.contrib.auth.models import User
from .models import Profile, Office, MeetingRequest, BrandingRequest, Chat

class UserSerializer(serializers.ModelSerializer):
    profile = serializers.PrimaryKeyRelatedField(queryset=Profile.objects.all(), source='profile')
    status = serializers.CharField(source='profile.status')
    office_rented = serializers.BooleanField(source='profile.office_rented')
    office_name = serializers.CharField(source='profile.office_name')

    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'status', 'office_rented', 'office_name']

class OfficeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Office
        fields = ['id', 'name', 'owner', 'status', 'rental_price']

class MeetingRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = MeetingRequest
        fields = ['id', 'requester', 'requested_time', 'requested_type', 'office_name', 'status']

class BrandingRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = BrandingRequest
        fields = ['id', 'requester', 'requested_time', 'requested_logo', 'office_name', 'status']


class ChatSerializer(serializers.ModelSerializer):
    class Meta:
        model = Chat
        fields = '__all__'
